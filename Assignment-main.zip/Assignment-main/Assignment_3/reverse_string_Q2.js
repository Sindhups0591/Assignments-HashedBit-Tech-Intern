let str = 'I love my India';
let words = str.split(' ');
let reversedWords = words.reverse();
let reversedStr = reversedWords.join(' ');

console.log(reversedStr);  
